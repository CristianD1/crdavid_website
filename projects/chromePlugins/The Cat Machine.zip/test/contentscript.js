$(document).ready(function() {
  
  var imageLinks = ["http://thecatapi.com/api/images/get?format=src&type=gif", "http://thecatapi.com/api/images/get?format=src&type=jpg", "http://thecatapi.com/api/images/get?format=src&type=png", "http://lorempixel.com/1920/1920/cats/"]
  var arrayLen = imageLinks.length;
  
  $('img').each(function(index, image){
    
    var selectPtr = Math.floor((Math.random() * arrayLen) + 0);
    
    if(imageLinks[selectPtr] == ""){
      imageLinks[selectPtr] = "http://thecatapi.com/api/images/get?format=src&type=gif";
    }
    
    $(image).attr('src', imageLinks[selectPtr]);
    
  });
});


(function(){
    // do some stuff
    setTimeout(arguments.callee, 60000);
})();